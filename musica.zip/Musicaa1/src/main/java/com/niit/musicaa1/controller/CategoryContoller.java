package com.niit.musicaa1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.musicaa1.bean.Category;
import com.niit.musicaa1.dao.CategoryDAO;

@Controller
	public class CategoryContoller
	{

		@Autowired
		CategoryDAO categoryDAO;
		

		@RequestMapping("/addCategory")
		public ModelAndView addCategory(@RequestParam(value = "categoryName") String categoryName,
				@RequestParam(value = "categoryDescription") String categoryDescription) {

			System.out.println("addCategory");
			String message = "Successfully created";
			ModelAndView mv = new ModelAndView("/success");
			mv.addObject("message", message);

			return mv;
		}
		
		
		
		@RequestMapping("category")
		public ModelAndView getAllCategories() {

			System.out.println("getAllCategories");
			
			List<Category> categorylist = categoryDAO.getAllCategories();
			
			ModelAndView mv = new ModelAndView("categorylist");
			mv.addObject("categorylist", categorylist);

			return mv;
		}
		
		
		@RequestMapping("/updateCategories")
		public ModelAndView updateCategory(@ModelAttribute("category") ArrayList<Category> categories)
		{
			int count = CategoryDAO.updateCategories(categories);
			
			System.out.println("updating category");
			ModelAndView mv = new ModelAndView("/categoryList");
			
			String message = count + " record(s) are updated";
			
		    List<Category> categoryList = categoryDAO.getAllCategories();
			mv.addObject("message",message);
			mv.addObject("categoryList", categoryList);
			
			return mv;
		}



}
