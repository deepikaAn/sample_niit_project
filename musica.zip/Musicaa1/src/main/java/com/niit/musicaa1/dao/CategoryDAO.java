package com.niit.musicaa1.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.musicaa1.bean.Category;


@Repository
public class CategoryDAO {

	public List<Category> getAllCategories() {

		List<Category> list = new ArrayList<Category>();
		Category c1 = new Category();
		c1.setId("1");
		c1.setName("classical istruments");
		c1.setDescription("this classical and indian instruments");

		list.add(c1);

		c1 = new Category();
		c1.setId("2");
		c1.setName("wind instruments");
		c1.setDescription("sound by vibrating column of air");

		list.add(c1);

		c1 = new Category();
		c1.setId("3");
		c1.setName("Guitars");
		c1.setDescription("acoustic and electric guitar");

		list.add(c1);

		return list;

	}

	public static int updateCategories(ArrayList<Category> categories) {
	
		return 1;
	}
}


