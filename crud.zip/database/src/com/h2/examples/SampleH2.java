package com.h2.examples;
import java.sql.*;



public class SampleH2 {
	public static void main(String[] args) {
        String url = "jdbc:h2:tcp://localhost/~/test";
        String username = "sa";
        String password = "";
        String query = "SELECT * FROM MUSICALINS";
        
        try (Connection con = 
	             DriverManager.getConnection (url, username, password);
	             Statement stmt = con.createStatement ();
	ResultSet rs = stmt.executeQuery (query)) {
        	while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("NAME");
                String brand = rs.getString("BRAND");
                String stringed = rs.getString("STRINGED");
                
                System.out.println("ID   " + id + "\n"
                + "NAME " + name + "\n"+"BRAND " + brand + "\n"
                + "STRINGED    " + stringed + "\n");

	          } 
	      } catch (SQLException e) {
	          System.out.println("SQL Exception: " + e);
	      } 
	   } }
        
            