package update;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
public class Update {
 
    public static void main(String[] args) {
         
        Connection con;
        Statement stmt;
        try {
            
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
            
            stmt = con.createStatement();
            stmt.execute("UPDATE MUSICALINS SET BRAND=PRIVIA WHERE ID=4");

    
            System.out.println("Updated queries: ");
         } 
        catch (SQLException e) {
            e.printStackTrace();
        
        }
    }
}
