package insert;

import java.sql.*;

public class Sample {
	 public static void main(String[] args) {
	       Connection connection;
	       Statement stmt ;
	       try
	       {
	           Class.forName("org.h2.Driver");
	           connection = DriverManager
	               .getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	            
	           stmt = connection.createStatement();
	           stmt.execute("INSERT INTO MUSICALINS (ID,NAME,BRAND,STRINGED)"
	           + "VALUES (6,'ACOUSTIC GUITAR','CARVIN','YES')");
	          
	       } 
	       catch (Exception e) {
	           e.printStackTrace();
	       }finally {
	           try {
	         
	           } catch (Exception e) {
	               e.printStackTrace();
	           }
	       }
	   }
	}




