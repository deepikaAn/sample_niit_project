
package delete;
import java.sql.*;

public class DelSample {

 
    public static void main(String[] args) {
    	
    	Connection   connection;
    	Statement    stmt;
        try
        {
        	 Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
             
            stmt = connection.createStatement();
            stmt.execute("DELETE FROM MUSICALINS WHERE ID = 2");
            System.out.println("delete succesfully");
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
        }
    }   

